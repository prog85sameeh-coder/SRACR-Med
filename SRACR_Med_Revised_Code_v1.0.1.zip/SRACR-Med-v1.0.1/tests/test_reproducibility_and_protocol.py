"""Small tests independent of protected patient datasets and trained checkpoints."""
import csv
import json
import sys
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'experiments' / 'adaptive_attacker'))
from src.adaptive_policy import AdaptiveCoverageController, global_risk_score
from src.crypto_benchmark import encrypt_selected_tiles, tile_scores, select_top
from adaptive_attacker import selections_for_image, require_no_split_leakage

class ProtocolTests(unittest.TestCase):
    def test_original_risk_threat_sweep_exact(self):
        with (ROOT / 'results/sensitivity/R1C3_RiskEquation_Verification.csv').open() as f:
            rows = list(csv.DictReader(f))
        weights = {'saliency': .30, 'clinical': .25, 'threat': .30, 'uncertainty': .15}
        # Given any fixed saliency/prior/uncertainty, the score MUST rise 0.30*deltaT.
        base = np.full((8,8), .38, dtype=np.float32)
        vals = [global_risk_score(base, .76, float(r['threat']), .40, weights)[0] for r in rows]
        archived = [float(r['recomputed_global_risk_mean']) for r in rows]
        np.testing.assert_allclose(np.diff(vals), np.diff(archived), atol=1e-12)

    def test_critical_override(self):
        ctrl = AdaptiveCoverageController([.30,.50,.70], .05, {1:.25,2:.50,3:.75,4:1.0})
        old, wanted, current, coverage, rotate = ctrl.update(.64,.95)
        self.assertEqual((wanted,current,coverage,rotate),(4,4,1.0,True))

    def test_lossless_authentication_and_nonce_accounting(self):
        arr = np.arange(150*88*3, dtype=np.uint32).reshape(150,88,3).astype(np.uint8)
        res = encrypt_selected_tiles(Image.fromarray(arr),{0,2,4},64)
        np.testing.assert_array_equal(res['recovered'], arr)
        self.assertEqual(res['metadata_overhead_est_bytes'],12*3)
        self.assertEqual(res['encrypted_tiles'],3)

    def test_adaptive_matched_selection_geometry(self):
        image = np.random.default_rng(42).integers(0,256,size=(73,137,3),dtype=np.uint8)
        scores = np.arange(6,dtype=np.float32) / 6
        selected = list(selections_for_image(image, scores,64,[.50],
                         ['sracr','random','content_variance','center_roi'],42,'img01'))
        self.assertEqual(len(selected),4)
        vals = [abs(r['actual_protected_pixel_fraction']-r['matched_target_pixel_fraction']) for r in selected]
        self.assertLessEqual(max(vals), 64*64/(73*137))
        self.assertEqual(selected[0]['method'],'sracr')

    def test_default_study_index_schema(self):
        import pandas as pd
        path = ROOT / "experiments/independent_leakage/dataset_index.csv"
        cols = pd.read_csv(path, nrows=0).columns
        self.assertTrue({"dataset_source", "image_path", "label", "final_split", "leakage_group"}.issubset(set(cols)))

    def test_split_error_detection(self):
        import pandas as pd
        df=pd.DataFrame([{'image_path':'sample','method':'sracr','budget':.25,'split':'train'},
                         {'image_path':'sample','method':'sracr','budget':.50,'split':'test'}])
        with self.assertRaises(ValueError):
            require_no_split_leakage(df)
        df = pd.DataFrame([
            {"image_path":"a", "method":"sracr", "budget":.25, "split":"train", "leakage_group":"x"},
            {"image_path":"b", "method":"sracr", "budget":.25, "split":"test", "leakage_group":"x"}])
        with self.assertRaises(ValueError):
            require_no_split_leakage(df)

if __name__ == '__main__':unittest.main()

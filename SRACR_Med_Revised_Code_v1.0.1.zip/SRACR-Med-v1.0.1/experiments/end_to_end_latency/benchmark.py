"""Audit end-to-end CPU inference / saliency / policy / selective encryption latency.

Both paths work on *raw uncompressed pixel bytes*. The full-file comparator is
one AES-256-GCM record; SRACR uses per-tile AEAD. Neither includes DICOM
serialization, disk/network I/O, or production key management.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments" / "independent_leakage"))
from independent_leakage import resolve_path, set_seed, SOURCES  # noqa: E402
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def measure(args):
    import torch
    import yaml
    from src.model import load_checkpoint
    from src.benchmark import analyze_priority, clinical_prior
    from src.adaptive_policy import global_risk_score, AdaptiveCoverageController
    from src.crypto_benchmark import tile_scores, select_top, encrypt_selected_tiles

    set_seed(args.seed)
    config = yaml.safe_load((ROOT / "configs" / "config.yaml").read_text(encoding="utf-8"))
    df = pd.read_csv(args.dataset_index)
    rows = df[(df["dataset_source"] == SOURCES[args.dataset]) & (df["final_split"] == "test")]
    if len(rows) < 1:
        raise ValueError("No test data in split manifest for dataset")
    if args.samples > 0:
        rows = rows.sample(n=min(args.samples, len(rows)), random_state=args.seed)
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    model, meta = load_checkpoint(args.victim_checkpoint, device)
    ctrl_cfg = config["controller"]
    model_image_size = int(meta["image_size"])
    tile_size = int(config["crypto"]["tile_size"])
    key = AESGCM.generate_key(bit_length=256)
    aes = AESGCM(key)
    data = []
    for rep in range(args.repeat):
        controller = AdaptiveCoverageController(ctrl_cfg["thresholds"], ctrl_cfg["hysteresis"],
                                                ctrl_cfg["coverage_by_level"])
        for _, r in rows.iterrows():
            p = resolve_path(str(r["image_path"]), args.dataset_root)
            if not p.exists():
                raise FileNotFoundError(f"Need image files: {p}")
            with Image.open(p) as im:
                image = im.convert("RGB")
            arr = np.asarray(image)
            t0 = time.perf_counter()
            pred, probs, uncertainty, reliability, map2d = analyze_priority(
                model, image, model_image_size, device, config["saliency"])
            # GPU work must complete before recording wall-clock stage time.
            if device == "cuda":
                torch.cuda.synchronize()
            t1 = time.perf_counter()
            clinical = clinical_prior(meta["class_names"][pred], config["clinical_prior"])
            g, _ = global_risk_score(map2d, clinical, args.threat, uncertainty, config["global_risk"]["weights"])
            _, _, level, budget, _ = controller.update(g, args.threat)
            scores = tile_scores(map2d, arr.shape[:2], tile_size)
            selected = select_top(scores, budget)
            t2 = time.perf_counter()
            partial = encrypt_selected_tiles(image, selected, tile_size, key=key)
            # encrypt_selected_tiles also decrypts internally; use its separately timed encryption result.
            t3 = time.perf_counter()
            raw = arr.tobytes()
            nonce = os.urandom(12)  # independent, cryptographically random nonce for each full-file AEAD record
            ct = aes.encrypt(nonce, raw, b"SRACR-full-comparator-raw-pixels")
            t4 = time.perf_counter()
            if aes.decrypt(nonce, ct, b"SRACR-full-comparator-raw-pixels") != raw:
                raise AssertionError("Full AES-GCM did not recover plaintext")
            if not np.array_equal(partial["recovered"], arr):
                raise AssertionError("Selective encryption failed round trip")
            data.append({
                "image_sha256_prefix": hashlib.sha256(str(r["image_path"]).encode()).hexdigest()[:12],
                "repeat": rep, "dataset": args.dataset, "threat": args.threat,
                "risk": g, "level": level, "budget": budget,
                "input_raw_bytes": len(raw), "n_tiles": partial["total_tiles"],
                "selected_tiles": partial["encrypted_tiles"],
                "inference_and_gradcam_ms": 1000 * (t1 - t0),
                "policy_and_selection_ms": 1000 * (t2 - t1),
                "selective_encryption_only_ms": partial["encryption_ms"],
                "selective_decryption_only_ms": partial["decryption_ms"],
                "selective_total_encrypt_ms": 1000 * (t2 - t0) + partial["encryption_ms"],
                "full_raw_pixel_encryption_ms": 1000 * (t4 - t3),
                "full_record_payload_bytes": len(ct) + 12,
                "selected_payload_bytes_including_gcm_tag": partial["encrypted_payload_bytes"],
                "selective_record_metadata_estimate_bytes": partial["metadata_overhead_est_bytes"],
            })
    detail = pd.DataFrame(data)
    summary = detail.groupby(["dataset", "threat", "level"], as_index=False).agg(
        observations=("repeat", "size"),
        mean_protection=("budget", "mean"),
        pipeline_ms_mean=("selective_total_encrypt_ms", "mean"),
        pipeline_ms_median=("selective_total_encrypt_ms", "median"),
        inference_ms_mean=("inference_and_gradcam_ms", "mean"),
        policy_ms_mean=("policy_and_selection_ms", "mean"),
        selective_encryption_ms_mean=("selective_encryption_only_ms", "mean"),
        full_aes_ms_mean=("full_raw_pixel_encryption_ms", "mean"),
    )
    summary["pipeline_to_full_aes_ratio"] = summary["pipeline_ms_mean"] / summary["full_aes_ms_mean"]
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    detail.to_csv(out / "end_to_end_detail.csv", index=False)
    summary.to_csv(out / "end_to_end_summary.csv", index=False)
    protocol = {"device": device, "samples": len(rows), "repeat": args.repeat, "seed": args.seed,
                "comparison": "raw uncompressed RGB, one full AEAD record vs selected per-tile AEAD",
                "excluded": ["disk I/O", "compression", "DICOM serialization", "network", "KMS/HSM"],
                "limitation": "controller/inference only in adaptive path; full-AES path assumes no diagnostic inference is needed"}
    (out / "end_to_end_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))


def main():
    p = argparse.ArgumentParser(description="End-to-end SRACR-Med vs full raw-pixel AES-GCM")
    p.add_argument("--dataset", choices=sorted(SOURCES), required=True)
    p.add_argument("--victim-checkpoint", required=True)
    p.add_argument("--dataset-index", default=str(ROOT / "experiments/independent_leakage/dataset_index.csv"))
    p.add_argument("--dataset-root", default=None)
    p.add_argument("--samples", type=int, default=20, help="0=all test images")
    p.add_argument("--repeat", type=int, default=3)
    p.add_argument("--threat", type=float, default=0.40)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--cpu", action="store_true")
    a = p.parse_args()
    if a.repeat < 1 or not (0 <= a.threat <= 1):
        p.error("require --repeat >=1 and threat in [0,1]")
    measure(a)

if __name__ == "__main__":
    main()

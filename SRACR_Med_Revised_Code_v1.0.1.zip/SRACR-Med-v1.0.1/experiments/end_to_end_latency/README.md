# End-to-end processing-cost experiment (NEW; requires external datasets/models)

```powershell
python experiments/end_to_end_latency/benchmark.py --dataset chest --victim-checkpoint models/chest.pt --dataset-root D:/DATA_ROOT --output-dir outputs/latency/chest --samples 20 --repeat 3 --threat 0.40 --cpu
```

Repeat for retinal and fundus data and for additional synthetic threat levels as required. The comparison separately times: (a) ResNet-18 inference/Grad-CAM and perturbation stability, (b) risk and controller and tile selection, (c) AES-GCM on selected tiles, and (d) one AES-GCM operation on the same raw RGB image. It is **not** a DICOM-file transport or multi-site deployment benchmark. Key management, disk I/O, network and compression are excluded from both paths. If full-file AES is faster, report that outcome rather than tuning numbers to favor SRACR.

Every result generated here is new and must not replace the published `CPU encryption latency` column, which measures only tile encryption time. The source archive has no raw images/checkpoints, so this experiment cannot be run on the medical study data from this ZIP alone.

Input rows default to `experiments/independent_leakage/dataset_index.csv`, which provides local paths, labels, split IDs and leakage groups. The lightweight `reproducibility/data_index/exact_split_manifest.csv` has source file hashes and group metadata but no local `image_path` column, so it is **not** a direct input to these execution scripts.

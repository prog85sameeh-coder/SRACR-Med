"""Train and evaluate mask-adapted adversaries against SRACR-Med.

Protocol: train/validation/test subjects are inherited from the frozen group-split
manifest. Attacker and victim weights are distinct; attacker training uses only
train/val samples, but the public protection *algorithm* may generate masks.
Any claimed result requires the raw images, victim checkpoints and an actual run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments" / "independent_leakage"))
from independent_leakage import (  # noqa: E402
    SOURCES, build_attacker, class_weights, content_variance_scores,
    center_scores, tile_geometry, stable_desc_order, choose_prefix_for_target_area,
    mask_tiles, resolve_path, set_seed, metrics_from_probs, bootstrap_mean_ci,
)

DEFAULT_METHODS = ["sracr", "random", "content_variance", "center_roi"]
DEFAULT_BUDGETS = [0.25, 0.50, 0.75]


def stable_random_order(n: int, seed: int, path: str, budget: float):
    value = hashlib.sha256(f"adaptive|{seed}|{path}|{budget:.5f}".encode()).digest()
    rng = np.random.default_rng(int.from_bytes(value[:8], "big"))
    return rng.permutation(n)


def selections_for_image(image_array, scores, tile_size, budgets, methods, seed, path):
    h, w = image_array.shape[:2]
    areas, boxes = tile_geometry(w, h, tile_size)
    scores = np.asarray(scores, dtype=np.float32)
    if len(scores) != len(boxes):
        raise ValueError(f"tile-count mismatch for {path}: {len(scores)} vs {len(boxes)}")
    orders = {
        "sracr": stable_desc_order(scores),
        "content_variance": stable_desc_order(content_variance_scores(image_array, boxes)),
        "center_roi": stable_desc_order(center_scores(boxes, w, h)),
    }
    total_area = int(areas.sum())
    for budget in budgets:
        selected = choose_prefix_for_target_area(orders["sracr"], areas, int(round(budget * total_area)))
        target_area = int(areas[selected].sum())
        for method in methods:
            if method == "random":
                order = stable_random_order(len(boxes), seed, path, budget)
            else:
                order = orders[method]
            chosen = (selected if method == "sracr" else
                      choose_prefix_for_target_area(order, areas, target_area))
            actual = int(areas[chosen].sum()) / total_area
            yield {
                "method": method,
                "budget": float(budget),
                "actual_protected_pixel_fraction": float(actual),
                "matched_target_pixel_fraction": float(target_area / total_area),
                "tile_size": int(tile_size),
                "selected_tiles": json.dumps([int(x) for x in chosen]),
            }


def prepare_masks(args):
    import torch
    from src.model import load_checkpoint
    from src.benchmark import analyze_priority
    from src.crypto_benchmark import tile_scores

    set_seed(args.seed)
    index = pd.read_csv(args.dataset_index)
    df = index[(index["dataset_source"] == SOURCES[args.dataset]) &
               (index["final_split"].isin(["train", "val", "test"]))].copy()
    if "valid_image" in df:
        df = df[df["valid_image"].astype(str).str.lower().eq("true")]
    if df.empty:
        raise ValueError("no rows in the selected dataset and split manifest")
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    victim, meta = load_checkpoint(args.victim_checkpoint, device)
    import yaml
    cfg = yaml.safe_load((ROOT / "configs" / "config.yaml").read_text(encoding="utf-8"))
    sal_cfg = cfg["saliency"]
    tile_size = int(cfg["crypto"]["tile_size"])
    # This is deliberately a *new* recalculation; not a replacement for archived v7.3 caches.
    rows = []
    for pos, (_, r) in enumerate(df.iterrows(), start=1):
        original_path = str(r["image_path"])
        filepath = resolve_path(original_path, args.dataset_root)
        if not filepath.exists():
            raise FileNotFoundError(f"Missing raw image: {filepath}. Provide --dataset-root")
        with Image.open(filepath) as img:
            image = img.convert("RGB")
            arr = np.asarray(image).copy()
            _, _, _, _, map2d = analyze_priority(victim, image, int(meta["image_size"]), device, sal_cfg)
            scores = [float(v) for _, v in tile_scores(map2d, arr.shape[:2], tile_size)]
        for condition in selections_for_image(arr, scores, tile_size, args.budgets,
                                              args.methods, args.seed, original_path):
            rows.append({
                "dataset": args.dataset, "image_path": original_path,
                "label": str(r["label"]), "split": str(r["final_split"]),
                "leakage_group": str(r.get("leakage_group", "")),
                "source_split_manifest": str(args.dataset_index), **condition,
            })
        if pos % 100 == 0:
            print(f"Prepared {pos}/{len(df)} images", flush=True)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    metadata = {"dataset": args.dataset, "n_images": len(df), "n_rows": len(rows),
                "seed": args.seed, "victim_checkpoint": args.victim_checkpoint,
                "methods": args.methods, "budgets": args.budgets,
                "test_cache_policy": "fresh_maps_not_archived_v7.3",
                "interpretation": "precomputed masks; NO adaptive-attacker results until train-eval is run"}
    out.with_suffix(".protocol.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(f"Saved {out}")


def require_no_split_leakage(df):
    if df.duplicated(["image_path", "method", "budget"]).any():
        raise ValueError("duplicate image/method/budget records in mask manifest")
    split_counts = df.groupby("image_path")["split"].nunique()
    if split_counts.max() > 1:
        raise ValueError("at least one image path belongs to multiple splits")
    if not set(df["split"]).issubset({"train", "val", "test"}):
        raise ValueError("unknown split")
    if "leakage_group" in df.columns:
        effective = df.loc[df["leakage_group"].notna() & df["leakage_group"].astype(str).ne("")].copy()
        if not effective.empty and effective.groupby("leakage_group")["split"].nunique().max() > 1:
            raise ValueError("verified leakage group assigned to multiple data splits")


def train_evaluate(args):
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, Dataset
    from torchvision import transforms
    from sklearn.metrics import f1_score

    set_seed(args.seed)
    full_df = pd.read_csv(args.mask_manifest)
    require_no_split_leakage(full_df)
    if args.method not in set(full_df["method"]):
        raise ValueError(f"method {args.method} not present in manifest")
    df = full_df[full_df["method"] == args.method].copy()
    # Split is immutable; no training label or mask selection from test enters optimization.
    classes = sorted(df["label"].astype(str).unique().tolist())
    class_to_idx = {n: i for i, n in enumerate(classes)}
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"

    class MaskedDataset(Dataset):
        def __init__(self, rows, training):
            self.rows = rows.reset_index(drop=True)
            ops = [transforms.Resize((args.image_size, args.image_size))]
            if training:
                ops += [transforms.RandomHorizontalFlip(), transforms.RandomRotation(5)]
            self.transforms = transforms.Compose(ops + [transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

        def __len__(self):
            return len(self.rows)

        def __getitem__(self, idx):
            r = self.rows.iloc[idx]
            src = resolve_path(str(r["image_path"]), args.dataset_root)
            with Image.open(src) as img:
                arr = np.asarray(img.convert("RGB")).copy()
            _, boxes = tile_geometry(arr.shape[1], arr.shape[0], int(r["tile_size"]))
            ids = np.asarray(json.loads(r["selected_tiles"]), dtype=np.int64)
            if len(ids) and (ids.min() < 0 or ids.max() >= len(boxes)):
                raise ValueError("tile index outside image geometry")
            masked = mask_tiles(arr, ids, boxes, fill=127)
            return self.transforms(masked), class_to_idx[str(r["label"])], str(r["image_path"]), float(r["budget"])

    train = df[df.split == "train"].copy()
    val = df[df.split == "val"].copy()
    test = df[df.split == "test"].copy()
    if min(len(train), len(val), len(test)) <= 0:
        raise ValueError("Missing train, val, or test records")
    train_ds, val_ds, test_ds = MaskedDataset(train, True), MaskedDataset(val, False), MaskedDataset(test, False)
    train_ld = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.workers)
    val_ld = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.workers)
    test_ld = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.workers)

    net, pretrained_used = build_attacker(len(classes), pretrained=not args.no_pretrained)
    net.to(device)
    criterion = nn.CrossEntropyLoss(weight=class_weights(train, classes).to(device))
    optimizer = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=1e-4)

    def predict(loader):
        net.eval()
        labels, probs, paths, budgets = [], [], [], []
        with torch.inference_mode():
            for x, y, p, b in loader:
                output = torch.softmax(net(x.to(device)), dim=1)
                labels.extend(y.numpy().tolist())
                probs.append(output.cpu().numpy())
                paths.extend(list(p))
                budgets.extend(b.numpy().tolist())
        return np.asarray(labels), np.concatenate(probs), paths, np.asarray(budgets)

    best_f1, best_state = -1., None
    history = []
    for epoch in range(1, args.epochs + 1):
        net.train()
        running_loss, n = 0.0, 0
        for x, y, _, _ in train_ld:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(net(x), y)
            loss.backward()
            optimizer.step()
            running_loss += float(loss.item()) * len(y)
            n += len(y)
        yv, pv, _, _ = predict(val_ld)
        val_f1 = float(f1_score(yv, pv.argmax(1), average="macro", zero_division=0))
        history.append({"epoch": epoch, "train_loss": running_loss / n, "val_macro_f1": val_f1})
        print(f"[{args.method}] {epoch}/{args.epochs} val macro F1={val_f1:.4f}", flush=True)
        if val_f1 > best_f1:
            best_f1 = val_f1
            best_state = {key: v.cpu().clone() for key, v in net.state_dict().items()}
    net.load_state_dict(best_state)
    yt, pt, paths, budgets = predict(test_ld)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for budget in sorted(set(budgets)):
        ix = np.isclose(budgets, budget)
        stats = metrics_from_probs(yt[ix], pt[ix])
        stats.update({"method": args.method, "budget": float(budget), "n_images": int(ix.sum()),
                      "model": "adaptively_trainable_MobileNetV3_Small", "mask_adapted": True,
                      "adaptation_training": "all listed matched budgets, train images only"})
        low, high = bootstrap_mean_ci((yt[ix] == pt[ix].argmax(1)).astype(float),
                                      args.bootstrap_reps, args.seed + int(100 * budget))
        stats["accuracy_ci95_low"] = low
        stats["accuracy_ci95_high"] = high
        results.append(stats)
    pd.DataFrame(results).to_csv(out / f"{args.method}_adaptive_attacker_summary.csv", index=False)
    pd.DataFrame({"image_path": paths, "budget": budgets, "method": args.method,
                  "true_index": yt, "predicted_index": pt.argmax(1),
                  "correct": (yt == pt.argmax(1)).astype(int)}).to_csv(
                      out / f"{args.method}_adaptive_attacker_test_predictions.csv", index=False)
    torch.save({"state_dict": best_state, "classes": classes, "method": args.method,
                "model": "mobilenet_v3_small", "best_val_macro_f1": best_f1,
                "pretrained_used": pretrained_used, "seed": args.seed,
                "training_budgets": sorted(set(train.budget.tolist()))},
               out / f"{args.method}_adaptive_attacker.pt")
    (out / f"{args.method}_adaptive_attacker_training.json").write_text(
        json.dumps({"history": history, "results": results, "method": args.method,
                    "mask_manifest": args.mask_manifest, "best_val_macro_f1": best_f1}, indent=2), encoding="utf-8")
    print(pd.DataFrame(results).to_string(index=False))


def main():
    ap = argparse.ArgumentParser(description="Prospective masked-view attacker experiment; no invented results")
    sp = ap.add_subparsers(dest="cmd", required=True)
    prep = sp.add_parser("prepare", help="generate matched masks for train, val and test from a frozen victim")
    prep.add_argument("--dataset", choices=sorted(SOURCES), required=True)
    prep.add_argument("--dataset-index", default=str(ROOT / "experiments/independent_leakage/dataset_index.csv"))
    prep.add_argument("--dataset-root", default=None)
    prep.add_argument("--victim-checkpoint", required=True)
    prep.add_argument("--output", required=True)
    prep.add_argument("--seed", type=int, default=42)
    prep.add_argument("--methods", nargs="+", choices=DEFAULT_METHODS, default=DEFAULT_METHODS)
    prep.add_argument("--budgets", nargs="+", type=float, default=DEFAULT_BUDGETS)
    prep.add_argument("--cpu", action="store_true")
    prep.set_defaults(action=prepare_masks)
    run = sp.add_parser("train-eval", help="fit a MobileNet attacker to masked train views; test on held-out views")
    run.add_argument("--mask-manifest", required=True)
    run.add_argument("--method", choices=DEFAULT_METHODS, required=True)
    run.add_argument("--dataset-root", default=None)
    run.add_argument("--output-dir", required=True)
    run.add_argument("--epochs", type=int, default=8)
    run.add_argument("--image-size", type=int, default=224)
    run.add_argument("--batch-size", type=int, default=32)
    run.add_argument("--workers", type=int, default=0)
    run.add_argument("--lr", type=float, default=3e-4)
    run.add_argument("--bootstrap-reps", type=int, default=2000)
    run.add_argument("--seed", type=int, default=42)
    run.add_argument("--no-pretrained", action="store_true")
    run.add_argument("--cpu", action="store_true")
    run.set_defaults(action=train_evaluate)
    args = ap.parse_args()
    if args.cmd == "prepare" and any(not 0 < b <= 1 for b in args.budgets):
        ap.error("all budgets must be in (0,1]")
    args.action(args)

if __name__ == "__main__":
    main()

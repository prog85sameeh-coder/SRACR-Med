# Adaptive-attacker experiment (NEW; not yet executed on medical images)

This is a prospective, stronger threat-model check. The **original** MobileNetV3-Small attacker was trained on clean images and tested with masked views; its reported residual accuracy is not an adaptive-attack estimate. This experiment trains a *separate* MobileNetV3-Small on protected views, with all masks created using the frozen ResNet-18 victim and frozen methodology. It never uses held-out test images or labels for optimization. A unique model is trained per selector; masks for three coverage budgets are mixed during training, and individual budgets are evaluated on test data.

For each dataset (`chest`, `retinal`, `split`) first prepare masks using original raw images, the archived split manifest, and the trained victim checkpoint:

```powershell
python experiments/adaptive_attacker/adaptive_attacker.py prepare --dataset chest --victim-checkpoint models/chest.pt --dataset-root D:/DATA_ROOT --output outputs/adaptive/chest_masks.csv --cpu
python experiments/adaptive_attacker/adaptive_attacker.py train-eval --mask-manifest outputs/adaptive/chest_masks.csv --method sracr --dataset-root D:/DATA_ROOT --output-dir outputs/adaptive/chest --epochs 8 --cpu
python experiments/adaptive_attacker/adaptive_attacker.py train-eval --mask-manifest outputs/adaptive/chest_masks.csv --method random --dataset-root D:/DATA_ROOT --output-dir outputs/adaptive/chest --epochs 8 --cpu
```

Repeat `train-eval` for `content_variance` and `center_roi`, and repeat the entire experiment for the other datasets. Include a clean-input attacker baseline using the already archived independent-attacker experiments for reference (not a paired adaptive estimate). For statistical claims, perform matched per-image paired tests using generated `_test_predictions.csv` files on the same dataset and budget, with prespecified multiple-comparison correction. The script saves per-image predictions and confidence intervals within each method; it does **not** claim a cross-method significance test automatically.

**Prerequisites:** raw image datasets, their frozen train/validation/test split, victim ResNet-18 checkpoints. These large inputs are **not** included in the ZIP. All new results must be explicitly marked as reruns and not silently substituted for the paper's original archived numbers. Avoid presenting successful runs as publication results before verifying class mapping, dataset paths, and the absence of group leakage.

Input rows default to `experiments/independent_leakage/dataset_index.csv`, which provides local paths, labels, split IDs and leakage groups. The lightweight `reproducibility/data_index/exact_split_manifest.csv` has source file hashes and group metadata but no local `image_path` column, so it is **not** a direct input to these execution scripts.
